interface QueryParamsInterface {
  pokemon?: string;
  sortBy?: string;
  type?: string;
  version?: string;
}

export default QueryParamsInterface;
