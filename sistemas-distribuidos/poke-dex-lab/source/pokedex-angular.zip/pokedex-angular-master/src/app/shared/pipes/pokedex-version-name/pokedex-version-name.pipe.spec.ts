import { PokedexVersionNamePipe } from './pokedex-version-name.pipe';

describe('PokedexVersionNamePipe', () => {
  it('create an instance', () => {
    const pipe = new PokedexVersionNamePipe();
    expect(pipe).toBeTruthy();
  });
});
